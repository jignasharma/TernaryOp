import java.util.Scanner;

public class Change_Case
{
    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);
         System.out.println("When user input in Uppercase convert to lowercase alphabet");
        String us = scanner.next();
        System.out.println(us.toLowerCase());




    }
}




